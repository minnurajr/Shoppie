 
 
<?php

include("connection.php");
session_start();
$bcid=$_SESSION['lid'];
$item_id=$_GET['id'];
$item_id=$_SESSION['item_id'];

?>

<style>

.container {
    border-radius:5px;
    background-image: url("highlight-bg.png");
    padding: 180px;
   
 
}
body {
  margin: 0;
  padding: 0;
  background:white;
  font-size: 16px;
  color: white;
  font-family: 'Roboto', sans-serif;
  font-weight: 300;
}
input[type=text],[type=date],[type=button],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit],[type=button] {
    
    background-color:white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}


.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}

</style>
</head>
<body >


<div class="container">

<fieldset>
 <form name="myForm" action="viewdetail.php" autocomplete="off" enctype="multipart/form-data" accept-charset="UTF-8"

   onsubmit="return validateForm()" method="post">

<div class="column">
<div class="row">
      
  
</div>
  </div>

 
   
<?php	
  $obj1=new db();
$selectt="select * from products WHERE prodid=$item_id";
$data1=$obj1->execute($selectt);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data1)>0)
{

while($row=mysqli_fetch_array($data1))
{	
$name=$row['name'];
$material=$row['material'];
$description=$row['description'];
$price=$row['price'];

?>
	 
	 <div class="row">

<div class="column">

    <img src="upload/<?php echo $row['image']; ?>"  style="width:25%" height="40%">
	<h3><i><?php echo $name;?><br>  </h3>

<h3><i><?php echo $material;?> </h3> 
<h3><i><?php echo $description;?> </h3> 
<h3  ><i> <?php echo $price;?></h3> <td>
<?php
 $prodid=$row['prodid'];
?>
<button type="submit" name="submit" id="submit" <a href="cart.php?id=<?php echo $prodid;?>">ADD TO CART</button>
	 <button type="button"><a href="ntot1.php?id=<?php echo $prodid;?>"> Buy Now</a></button></td> 
     
  
	  
      </div>
	 
	
	  
 <?php
 }
 

}
?>


</fieldset>
</body>
</form>
 <?php
	
  if(isset($_POST['submit']))
  {
	   
$name=$_POST["name"];

$price=$_POST["price"] ;

$image=$_POST["image"] ;

$sql="INSERT INTO `cart`(`cid`, `prodid`, `loginid`, `title`, `image`, `qty`, `price` ) VALUES (null,'$item_id','$bcid','$name','$image','1','$price')";
$obj=new db();
$obj->execute($sql);

					
 }			
			
	?>			  
<html>