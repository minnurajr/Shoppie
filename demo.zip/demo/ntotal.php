<!DOCTYPE html>
<html>

<head>
<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: purple;
}

li {
  float: left;
}

li a {
  display: block;
  color: purple;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}


.active {
  background-color: purple;
}
</style>
</head>
<body>


</body>
</html>

<?php
/*
$price=$_POST['price'];
$quantity=$_POST['quantity'];
$total=$price*$quantity;
//$total=$amount;

*/

session_start();
include "connection.php";
$item_id=$_SESSION['item_id'];
$qty=$_SESSION['qty'];

  $obj=new db();
$selec="select * from products WHERE prodid='$item_id'";
$data1=$obj->execute($selec);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data1)>0)
{

while($row=mysqli_fetch_array($data1))
{
$itemname=$row['name'];	
$price=$row['price'];
$stock=$row['no_item'];

$total=$price*$qty;

}
}

?>




<!DOCTYPE html>
<html>
<head>

<script>
function validateForm() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Registeration completed");
        return false;
    }
}
</script>
<style>


body
{
<body background="regcustomer.jpg">
}

.img{
	width:180px;
	height:50px;
    }
.centered {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.text{
	width:105%;
	height:50%;
	margin-left:200px;
	margin-top:100px;
	 column-count: 2;
      }
.footer {
  position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height:8%;
   background-color: black;
   margin-top:100px;
}


input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
body {
  
   background-image: url("table.jpg");
  font-size: 16px;
  color: #222;
  font-family: 'Roboto', sans-serif;
  font-weight: 800;
}


input[type=text],[type=date],[type=radio],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}


input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
.container {
    border-radius:5px;
    background-image: url("regstaff.jpg");
    padding: 20px;
    margin-left:400px;
width:40%;
 
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}


/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body>

<br><div class="container">
<br><center><h1>PAYMENT</h1></center>
<br><fieldset>
 <form name="myForm" action="payment1.php"

   onsubmit="return validateForm()"  method="post">
<div class="row">
      <div class="col-25">
        <label for="TOTL">TOTAL:</label>
      </div>
      <div class="col-75">
	  
        <input type="text" name="total"   readonly value="<?php echo $total;?>" required="">
		
	<br><br><button  type="submit" id="<?php echo $prodid;?>">BUY NOW </button>
      </div>
	  </div>
   


  </div>

 

</fieldset>
</body>

</form>

<html>