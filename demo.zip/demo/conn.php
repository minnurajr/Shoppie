<?php

	$con = mysqli_connect("localhost", "root", "","keshu");
	//mysqli_select_db($con, "keshu");

?>