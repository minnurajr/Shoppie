<html>


<body>
<?php
mysqli_connect("localhost","root","")or die("not connected");
mysqli_select_db("keshu")or die("no such database");
?>
</body>
</html>