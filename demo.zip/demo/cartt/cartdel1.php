<?php
include 'dbconnect.php';
session_start();
$cid=$_SESSION['cartid'];
$sql = "DELETE FROM `cart` WHERE cart_id='$cid'";
$r=mysqli_query($con,$sql);
if($r)

{
  
  ?>
   <script>

 alert("Item deleted");
 window.location="cartr1.php";

</script>
<!-- <?php
/*else*/
{?>
  <script>
    alert("Error");
  </script> -->
  <?php
}

}
mysqli_close($con);
?>



?>
