<?php
session_start();
include('dbconnect.php');
$pid=$_POST['id'];
$logid=$_SESSION['loginid'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>FURNITURE MART</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- <style>
    	div{
         border-color: color|transparent|initial|inherit;
    	}

    </style> -->
  </head>
  <body class="goto-here">
		<div class="py-1 bg-primary">
    	<div class="container">
    		<div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
	    		<div class="col-lg-12 d-block">
		    		<div class="row d-flex">
		    			<div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
						    <span class="text">+ 1235 2355 98</span>
					    </div>
					    <div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
						    <span class="text">youremail@email.com</span>
					    </div>
					    <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right">
						    <span class="text">3-5 Business days delivery &amp; Free Returns</span>
					    </div>
				    </div>
			    </div>
		    </div>
		  </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">MOOPANS OIL MILL</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.html" class="nav-link">Home</a></li>
	          <li class="nav-item active dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Shop</a>
              <div class="dropdown-menu" aria-labelledby="dropdown04">
              	<a class="dropdown-item" href="shop.html">Shop</a>
              	<a class="dropdown-item" href="wishlist.html">Wishlist</a>
                <a class="dropdown-item" href="product-single.html">Single Product</a>
                <a class="dropdown-item" href="cart.html">Cart</a>
                <a class="dropdown-item" href="checkout.html">Checkout</a>
              </div>
            </li>
	          
	          <li class="nav-item cta cta-colored"><a href="cart.html" class="nav-link"><span class="icon-shopping_cart"></span>[0]</a></li>

	        </ul>
	      </div>
	    </div>
	  </nav>
	  
    <?php
    $query = "select * from products where prodid='$pid'";
    
        $r=mysqli_query($con,$query);
        if(mysqli_num_rows($r)>0){
          while ($row = mysqli_fetch_array($r)) {
            
                $itemname=$row['name'];
                $material=$row['material'] ;
                $amount=$row['price'] ;
                $des=$row['description'] ;
            ?>

    <form action="fsingleproduct.php" method="POST">    		
    <section class="ftco-section">
    	<div class="container">
    		<div class="row">
    			
    			 <div class="col-lg-6 mb-5 ftco-animate">
    				<img src="/fur/admin/architectui-html-free/upload/<?php echo $row['image']; ?>"  style="width:30%" height="0%"> 
    			</div> 
    		   <div class="col-lg-6 product-details pl-md-5 ftco-animate">

           


    				<h3><input type="text" name="cat" value="<?php echo $itemname; ?>" ></h3>
    				<!--<h3><input type="text" name="qty" value="<?php echo $qty; ?>"></h3>-->
    				<input type="hidden" name="login" value="<?php echo $logid; ?>">
    				<!-- <input type="hidden" name="total" value=""> -->
    				
    				
    				<p class="price"><span><input type="text" name="price" value="<?php echo $amount; ?>"></span></p> 
    				<div class="w-100"></div>
							<div class="input-group col-md-6 d-flex mb-3">
	             
	            		QUANTITY:  
	             	<input type="text" id="quantity" name="quantity" class="form-control input-number" value="1" min="1" max="100">
	        
	          	</div>

	          	<div class="w-100"></div>
	          	<div class="col-md-12">
	          		
    			 <!-- <form action="cart.php" method="POST" > -->
      <input type="hidden" name="id" value="<?php echo $row['product_id']; ?>"/>
      <input type="submit" name="submit" value="ADD TO CART" class="btn btn-primary py-3 px-5">
    </form>
    			</div>

    		</div>
    	</div>
    				

    		</div>
    	</div>
   
</div>
</section>
</form>

	<?php
         }
        	}
        	?>




  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  </body>
</html>

 