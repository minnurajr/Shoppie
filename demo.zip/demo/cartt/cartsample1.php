<?php
include("connection.php");
session_start();
$bcid=$_SESSION['lid'];
$item_id=$_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Contacts</title>
 <div class="navbar">
   <a href="http://localhost/fur/product.php" color=blue>Home</a>
   </div>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/grid.css" type="text/css" media="screen">

<script src="js/jquery-1.6.2.min.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
<![endif]-->
</head>
<body id="page5" background="bg_main.png">
<!--==============================header=================================-->
<header>
  
  <div class="row-2">
    <div class="main">
      <div class="container_12">
        <div class="grid_9">
          <h1> <a class="logo" href="index.html">F<strong>w</strong>orld</a></h1>
        </div>
       
        <div class="clear"></div>
      </div>
    </div>
  </div>
</header>
    <?php
		$query = "select * from products where prodid='$item_id'";
		
        $r=mysqli_query($con,$query);
        if(mysqli_num_rows($r)>0){
        	while ($row = mysqli_fetch_array($r)) {
        		
        		    $itemname=$row['name'];
                $material=$row['material'] ;
                $amount=$row['price'] ;
                $des=$row['description'] ;
        		?>

        	<form action="" method="POST">	
    <section class="ftco-section">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-6 mb-5 ftco-animate">
                <img src="upload/<?php echo $row['image']; ?>"  style="width:30%" height="0%"> 
    			</div>
    		   <div class="col-lg-6 product-details pl-md-5 ftco-animate">

            <h3><input type="text" name="cat" value="<?php echo $itemname; ?>" ></h3>
            <!--<h3><input type="text" name="qty" value="<?php echo $qty; ?>"></h3>-->
            <input type="hidden" name="login" value="<?php echo $logid; ?>">
            <!-- <input type="hidden" name="total" value=""> -->
            
            
            <p class="price"><span><input type="text" name="price" value="<?php echo $amount; ?>"></span></p> 
            <div class="w-100"></div>
              
               
							<div class="input-group col-md-6 d-flex mb-3">
	             
	            		QUANTITY:  
	             	<input type="text" id="quantity" name="quantity" class="form-control input-number" value="1" min="1" max="100">
	        
	          	</div>
	          	<div class="w-100"></div>
	          	<div class="col-md-12">
	          		
    			 
      <input type="hidden" name="id" value="<?php echo $row['prodid']; ?>"/>
      <input type="submit" name="submit" value="ADD TO CART" class="btn btn-primary py-3 px-5">
    </form>
    			</div>

    		</div>
    	</div>
    				

    		</div>
    	</div>
   
</div>
</section>

	<?php
         }
        	}
        	?>




  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  </body>
</html>