<?php
$con=mysqli_connect("localhost","root","","keshu")or die("unable to connect");
?>