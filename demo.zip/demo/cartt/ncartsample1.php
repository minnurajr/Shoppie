
<?php

include("connection.php");
session_start();
 $Lid=$_SESSION['lid'];
 $item_id=$_GET['id'];
 //$prodid=$_GET['prodid'];
$obj=new db();
$select="select * from products where prodid=$item_id";
$data=$obj->execute($select);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data)>0)
{

while($row=mysqli_fetch_array($data))
{	


$itemname=$row['name'];
$material=$row['material'] ;
$price=$row['price'] ;
$des=$row['description'] ;
?>



<!DOCTYPE html>
<html>
<head>
<style>


* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>

<div class="container">

 <form name="myForm" method="post" 


   onsubmit="return validateForm()" enctype="multipart/form-data" accept-charset="UTF-8" >
   
    <div class="row">

<div class="column">

    <img src="upload/<?php echo $row['image']; ?>"  style="width:30%" height="40%">
	

	<h3><i><?php echo $itemname;?><br>  </h3>

<h3><i><?php echo $material;?> </h3> 
<h3  ><i> <?php echo $price;?></h3> <td>
<?php $prodid=$row['prodid'];
?>
<h3  > <?php echo $des;?></h3> <td>
 
 <button type="button" id="submit" name="submit" ><a href="http://localhost:8080/demo/cartt/cartsample1.php"> Quick View</a></button></td>
<button type="button"><a href="ntot1.php?id=<?php echo $prodid;?>"> Buy Now</a></button></td>
  </div>
 
  <!---------
 // <?php
  //include("coo.php");

  //if(isset($_POST['submit']))
 // {
//	  $sql="select * from products where prodid='$prodid'";
//$run_query = mysqli_query($conn,$sql);
				//$row = mysqli_fetch_array($run_query);

//$itemname=$row['name'];
//$material=$row['material'] ;
//$price=$row['price'] ;
//$des=$row['description'] ;
//$image=$row['image'] ;

				
//$sql="insert into cart(prodid,loginid,title,image,qty,price,total) values('$prodid','$Lid','$itemname','$image','1','$price','$pro_price')";
//$run_query = mysqli_query($conn,$sql);
					
 //}			
			
				
	
  
  //?>
 

<?php
 }
 
}

?>
 </form>
 </body>

</html>
