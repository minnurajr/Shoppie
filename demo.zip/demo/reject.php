<?php
include "conn.php";

$b=$_POST['id'];
$sql=mysqli_query($con,"delete  from registration_shop where loginid='$b'");
$sqll=mysqli_query($con,"delete  from login where loginid='$b'");
if ( $sql && $sqll ){
 echo "<script>alert('Removed');
      window.location='shopreg.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>