
<?php

include("connection.php");
session_start();
 
$obj=new db();
$select="select * from products where cid = 1";
$data=$obj->execute($select);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data)>0)
{

while($row=mysqli_fetch_array($data))
{	


$itemname=$row['name'];
$material=$row['material'] ;
$amount=$row['price'] ;
$des=$row['description'] ;
?>



<!DOCTYPE html>
<html>
<head>
<style>


* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>

<div class="container">

 <form name="myForm" method="post" action="payment.php"


   onsubmit="return validateForm()" enctype="multipart/form-data" accept-charset="UTF-8" >
    <div class="row">

<div class="column">

    <img src="upload/<?php echo $row['image']; ?>"  style="width:30%" height="40%">
	

	<h3><?php echo $itemname;?><br>  </h3>

<h3  ><?php echo $material;?> </h3> 
<h3  > <?php echo $amount;?></h3> <td>
<h3  > <?php echo $des;?></h3> <td>
 
  <?php $prodid=$row['prodid'];
?>
<button type="button" id="submit" name="submit" ><a href="viewdetail.php?id=<?php echo $prodid;?>">Quick View</a></button></td>
  <button type="button"><a href="ntot1.php?id=<?php echo $prodid;?>"> Buy Now</a></button></td>
  </div>
  </form>
<?php
 }
 
}

?>





 </body>

</html>
