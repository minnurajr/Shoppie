<?php

  if(isset($_POST['submit']))
  {
	  $item_id=$_GET["$id"];
$name=$_GET["$id1"];

$price=$_GET["$id2"] ;

$image=$_GET["$id3"] ;

$sql="INSERT INTO `cart`(`cid`, `prodid`, `loginid`, `title`, `image`, `qty`, `price` ) VALUES (null,'$item_id','$bcid','$name','$image','1','$price')";
$obj=new db();
$obj->execute($sql);
if($obj)
{
echo "<script> alert('success');
 window.location=''</script>";
}
else
{
echo "<script> alert('error');
 window.location='cart.php'</script>";	
}
 }			
			
	?>			  