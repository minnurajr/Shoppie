<?php
session_start();
include("connection.php");
$Lid=$_SESSION['lid'];
?>

<html>
<head>

</head>

<body>


<table width="1236" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="291" height="363"></td>
    <td width="366" valign="top"><div align="center">
      <p>Edit your profile </p>
      <form name="form1" method="post" action="editprofile2.php">
	    <?php
	 
	  
	  include("connn.php");
	  $s1=$_POST["name"];
	  $s2=$_POST["dob"];
	  $s3=$_POST["gender"];
	  $s4=$_POST["mobno"];
	  $s5=$_POST["pincode"];
	  $s6=$_POST["hname"];
	  $s7=$_POST["street"];
	   $s8=$_POST["locality"];
	    $s9=$_POST["did"];
		 $s11=$_POST["state"];
	  $s="update registration_user set name='$s1',dob='$s2',gender='$s3',mobno='$s4',pincode='$s5',hname='$s6',street='$s7',locality='$s8',did='$s9',state='$s11' where lid='$lid'";
	  mysqli_query($s);
// $s=mysql_query("select * from coordinators where coid='$coid'");
	//  if($row=mysql_fetch_array($s))
	  //{
	  //$name=$row[1];
	  //$addr=$row[2];
	  //$place=$row[3];
	  //$pin=$row[4];
	  //$ph=$row[5];
	  //$qlfn=$row[6];
	  //$gender=$row[7];
	  
	   ?>
	  
        
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form>
      <p>&nbsp;</p>
    </div></td>
    <td width="579"></td>
  </tr>
  <tr>
    <td height="13"></td>
    <td></td>
    <td></td>
  </tr>
</table>
</body>
</html>
