<?php
include 'conn.php';

$q="select * from brand";
$sq=mysqli_query($con,$q);

$q="select * from category";
$sq1=mysqli_query($con,$q);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Shoppie</title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap-3.3.6-dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="navbar navbar-default navbar-fixed-top" id="topnav">
		<div class="container-fluid">
			<div class="navbar-header">
				<a href="index.html" class="navbar-brand">Shoppie</a>
			</div>


		</div>
	</div>
	<p><br><br></p>
	<p><br><br></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="err_msg"></div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Add Stock</div>
					<div class="panel-body">
				<form method="post" action="regs.php" autocomplete="off" enctype="multipart/form-data" accept-charset="UTF-8" >
					<div class="row">
						<div class="col-md-6">
							<label for="cid">Product Category</label>
							<select name="cid" id="cid" class="form-control" required/>
							<option value="">Category</option>
							<?php 
							 while($r=mysqli_fetch_array($sq1))  
							 {
							?>
                    <option value="<?php echo $r['cid'];
					?>"><?php echo $r['ctitle']?> 
					<?php
							 }
                      ?>				
							</select>
						</div>
                          <div class="row">
						<div class="col-md-6" name="bid" class="form-control">
						<label for="bid">Product brand</label>
						<select name="bid" id="bid"  class="form-control" required/>
							<option value="">Brand</option>
							<?php 
							 while($r=mysqli_fetch_array($sq))  
							 {
							?>
                    <option value="<?php echo $r['bid'];?>">
					<?php echo $r['btitle']?> 
					<?php
							 }
                      ?>						
							
							</select>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<label for="title">No Of Item</label>
							<input type="text" id="no_item" name="no_item" pattern="[0-9]+(\.[0-9][0-9]?)?" class="form-control" required/>
						</div>
						
						<div class="col-md-6">
							<label for="price">Price</label>
							<input type="text" id="price" name="price" class="form-control" pattern="[0-9]+(\.[0-9][0-9]?)?" required/>
						</div>
					</div>
                           <div class="col-md-6">
							<label for="name">Name</label>
							<input type="text" id="name" name="name" class="form-control" required/>
						   </div>
                       

					<div class="row">
						<div class="col-md-6">
							<label for="mobile">Description</label>
							<input type="text" id="description" name="description" class="form-control" required/>
						</div>
						
					</div>
                        <div class="row">
						<div class="col-md-6">
							<label for="mobile">Size</label>
							<select name="size" id="size" name="size" class="form-control" required/>
							
                    <option>L</option>
                    <option>M</option>
                    <option>S</option>
                    </select>
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-6">
							<label for="image">Image</label>
							<input type="file" id="picture" name="picture" accept=".jpg, .png, .jpeg" class="form-control" required/>
						</div>
						<div class="col-md-6"></div>
					</div>

					<div class="row">
						<div class="col-md-12">
							<label for="address2">Material</label>
							<select name="material" id="material" name="material" class="form-control" required/>
                      <option>Shifon</option>
                      <option>Cotton</option>
                      <option>polyster</option>
                      <option>nylon</option>
                      <option>silk</option>
                      <option>Chunkidi</option>
                      <option>Jeans</option>
                      </select>
							
						</div>
					</div>

					<br><br>
					<div class="col-md-12">
						<input type="submit" class="btn btn-primary" value="submit" name="submit" id="submit">
					</div>

					</div>
					</div>
					</form>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>



<?php

include "connection.php";

if(isset($_POST['submit']))
{
$img =$_FILES['picture']['name'];
$temp_name =$_FILES['picture']['tmp_name'];
//echo  $img;
move_uploaded_file($temp_name,'upload/' .$img);
$nc=$_POST["cid"];
$do=$_POST["bid"];
$gen=$_POST["no_item"];
$no=$_POST["price"];
$mn=$_POST["name"];
$em=$_POST["description"];
$pi=$_POST["size"];

$hn=$_POST["material"]; 

$sqlll="INSERT INTO `products`(`prodid`, `cid`, `bid`, `no_item`, `description`, `size`, `material`, `price`, `image`, `name`,`role`) VALUES (NULL,'$nc','$do','$gen','$em','$pi','$hn','$no','$img','$mn','shop')";
 $objjj=new db();
 $objjj->execute($sqlll);
 echo "<script> alert('success')";
 
}
?>
		


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js"></script>
	<script src="assets/bootstrap-3.3.6-dist/js/bootstrap.min.js"></script>
	<script src="main.js"></script>
</body>
<style> .foot{text-align: center;}
</style>
</html>