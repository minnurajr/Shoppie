
<?php

include("connection.php");
session_start();
 $Lid=$_SESSION['lid'];
 //$prodid=$_GET['prodid'];
$obj=new db();
$select="select * from products where cid = 6";
$data=$obj->execute($select);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data)>0)
{

while($row=mysqli_fetch_array($data))
{	


$itemname=$row['name'];
$material=$row['material'] ;
$price=$row['price'] ;
$des=$row['description'] ;
$stock=$row['no_item'];
?>



<!DOCTYPE html>
<html>
<head>
<style>


* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>

<div class="container">

 <form name="myForm" method="post" 


   onsubmit="return validateForm()" enctype="multipart/form-data" accept-charset="UTF-8" >
   
    <div class="row">

<div class="column">

    <img src="upload/<?php echo $row['image']; ?>"  style="width:30%" height="40%">
	

	<h3><i><?php echo $itemname;?><br>  </h3>

<h3><i><?php echo $material;?> </h3> 
<h3  ><i> <?php echo $price;?></h3> 
<h3>Stock=<?php echo $stock;?></h3><td>
<?php $prodid=$row['prodid'];
?>
<h3  > <?php echo $des;?></h3> <td>
 
  <button type="button" id="submit" name="submit" ><a href="cart.php"> Add To Cart</a></button></td>
<button type="button"><a href="ntot1.php?id=<?php echo $prodid;?>"> Buy Now</a></button></td>
  </div>
 
  <!---------
 // <?php
  //include("coo.php");

  //if(isset($_POST['submit']))
 // {
//	  $sql="select * from products where prodid='$prodid'";
//$run_query = mysqli_query($conn,$sql);
				//$row = mysqli_fetch_array($run_query);

//$itemname=$row['name'];
//$material=$row['material'] ;
//$price=$row['price'] ;
//$des=$row['description'] ;
//$image=$row['image'] ;

				
//$sql="insert into cart(prodid,loginid,title,image,qty,price,total) values('$prodid','$Lid','$itemname','$image','1','$price','$pro_price')";
//$run_query = mysqli_query($conn,$sql);
					
 //}			
			
				
	
  
  //?>
 
  
  -------->
  
  
  
  
 

<?php
include "coo.php";
if(isset($_POST['submit'])){
			if(!(isset($_SESSION['lid']))){echo "
						<div class='alert alert-danger' role='alert'>
  					<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
  					<strong>Hey there!</strong> Sign in to buy stuff!
				</div>
					";}
			else{
			$bcid=$_SESSION['lid'];
            $item_id=$_GET['id'];
			//$uid=$_SESSION['uid'];
			$sql = "SELECT * FROM cart WHERE prodid = '$item_id' AND loginid = '$bcid'";
			$run_query=mysqli_query($conn,$sql);
			$count=mysqli_num_rows($run_query);
			if($count>0)
			{
				echo "<div class='alert alert-danger' role='alert'>
  					<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
  					<strong>Success!</strong> Already added!
				</div>";
			}
			else
			{
				$sql = "SELECT * FROM products WHERE prodid = '$item_id'";
				$run_query = mysqli_query($conn,$sql);
				$row = mysqli_fetch_array($run_query);
				$id = $row["prodid"];
				$pro_title = $row["name"];
				$pro_image = $row["image"];
				$pro_price = $row["price"];

				
				$sql="INSERT INTO cart(prodid,loginid,title,image,qty,price,total) VALUES('$item_id','$bcid','$pro_title','$pro_image','1','$pro_price','$pro_price')";
				$run_query = mysqli_query($conn,$sql);
				if($run_query){
					echo "
						<div class='alert alert-success' role='alert'>
  					<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
  					<strong>Success!</strong> Product added to cart!
				</div>
					";
				}
			}
			}
		}
	

?>
<?php
 }
 
}

?>
 </form>
 </body>

</html>
