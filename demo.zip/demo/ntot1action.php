<?php

session_start();

include("conn.php");
if(isset($_POST['submit']))
{
$quantity=	$_POST["quantity"];

$_SESSION['qty']=$_POST["quantity"];

$stock=	$_POST["stock"];

$item_id=$_SESSION['item_id'];
	  
 
$re= mysqli_query($con,"select * from products where prodid=$item_id");



	
		   

if(mysqli_num_rows($re)>0)
{
	if($stock<$quantity)
	{
		echo "<script> alert('unsufficient stock');
          window.location='womenhome.php' </script>";
	}
	else{
		
	$new_qty= $stock-$quantity;
	
	
	$result=mysqli_query($con,"update products SET no_item=$new_qty where prodid=$item_id");
	if($result)
	{
	echo "<script> 
           window.location='ntotal.php'</script>";
	
	}
	else
	{
	echo "error";
	}
	
	}

}
	  


 

}

?>
