<?php
include("connection.php");
include("check_session.php");
$Lid=$_SESSION['lid'];
$obj=new db();
	$select="select * from registration_user where loginid='$Lid'";
	$data=$obj->execute($select);
	if(mysqli_num_rows($data)>0)
	{
		while($row=mysqli_fetch_array($data))
		{
			$name=$row['name'];
			
			?>


<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>The Shoppie</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>
	
	<!-- Header section -->
	<header class="header-section header-normal">
		<div class="container-fluid">
			<!-- logo -->
			<div class="site-logo">
				<img src="img/logon.png" alt="logo">
			</div>
			<!-- responsive -->
			<div class="nav-switch">
				<i class="fa fa-bars"></i>
			</div>
			<div class="header-right">
				<a href="cart.php" class="card-bag"><img src="img/icons/bag.png" alt=""><span>2</span></a>
				
			</div>
			
			<!-- site menu -->
			<ul class="main-menu">
			<li><a href="userhome.php" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>Hello, <?php echo $row['name'];?></a>
				<ul class="dropdown-menu">
                      
					 		  
                                   </ul>
				<li><a href="index.html">Home</a></li>
				<li><a href="womenhome.php">Woman</a></li>
				<li><a href="menhome.php">Men</a></li>
				<li><a href="changeps.php">Change Password</a></li><br>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="editprofile1.php">EditProfile</a></li>
				<li><a href="shopnotif.php">Notifications</a></li>
				<li><a href="logouts.php">Logout</a></li>





				
			</ul>
		</div>
	</header>
	<!-- Header section end -->


	<!-- Page Info -->
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="">Home</a> /
				<span>UserHome</span>
			</div>
			<img src="img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	<!-- Page Info end -->
 <div class="one-time">
	    <div><img src="assets/images/car1.jpg"></div>
	    
  	</div>

 
	<!-- Page -->
	
	
	<?php 
		}
	}
?>
					
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>


