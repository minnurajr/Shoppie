 
 
<?php

include("connection.php");
session_start();
$bcid=$_SESSION['lid'];
$item_id=$_GET['id'];
$_SESSION['item_id']=$item_id;
$x=$_SESSION['item_id'];
//$price=$_SESSION['price'];
//echo "<script>alert($item_id);</script>";
//$amount=$_SESSION['amount'];
 
$obj=new db();
$select="select * from registration_user WHERE loginid=$bcid";
$data=$obj->execute($select);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data)>0)
{

while($row=mysqli_fetch_array($data))
{	
$name=$row['name'];
$hname=$row['hname'];
$locality=$row['locality'];

//$DOB=$row['DOB'];


?>

<style>

.container {
    border-radius:5px;
    background-image: url("bg.jpg");
    padding: 180px;
   
 
}
body {
  margin: 0;
  padding: 0;
  background:white;
  font-size: 16px;
  color: white;
  font-family: 'Roboto', sans-serif;
  font-weight: 300;
}
input[type=text],[type=date],[type=button],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit],[type=button] {
    
    background-color:green;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}


.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}

</style>
</head>
<body >


<div class="container">

<fieldset>
 <form name="myForm" action="ntot1action.php" autocomplete="off" enctype="multipart/form-data" accept-charset="UTF-8"

   onsubmit="return validateForm()" method="post">

<div class="column">
<div class="row">
      <div class="col-25">
        <label for="entername">Delivered:</label>
      </div>
    
<div class="row">
    
	 </div>
	
	<h3><?php echo $name;?><br>  
	  </h3>
	<h3><?php echo $hname;?><br>  </h3>
	<h3><?php echo $locality;?><br>  </h3>
	

       
    
     

	  


 

</div>
  </div>

 <?php
 }
 

}
?>


<div class="row">
      <div class="col-25">
        <label for="quantity">QUANTITY:</label>
      </div>
      <div class="col-75">
       <input type="text"  name="quantity" id="quantity"  required="">
        
      </div>
    </div>
   
<?php	
  $obj=new db();
$selec="select * from products WHERE prodid=$item_id";
$data1=$obj->execute($selec);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data)>0)
{

while($row=mysqli_fetch_array($data1))
{	
$price=$row['price'];
$_SESSION['price']=$price;

$stock=$row['no_item'];
?>

	<div class="row">
     <div class="col-25">
        <label for="price">STOCK:</label>
		 </div>
		 <div class="col-75">
        <input type="text"  name="stock"  readonly  value="<?php echo $stock;?>" required="">
      </div>
	  <div class="row">
     <div class="col-25">
        <label for="price">PRICE:</label>
		 </div>
	  <div class="col-75">
        <input type="text"  name="price"  readonly  value="<?php echo $price;?>" required="">
      </div>
	  </div>
	  
	  
	  
     
  <!--<h3><?php echo $price;?></h3>
	  
      </div>-->
	  
	  
	  
	  
 <?php
 }
 

}
?>

	  

<br><br><button  type="submit" id="submit" name="submit">BUY NOW </button> </td>


</fieldset>
</body>
</form>



<html>