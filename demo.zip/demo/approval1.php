<?php
include 'conn.php';
?>

<!DOCTYPE html>


<html>
<head>
<style>
body {
  margin: 0;
  font-family: Times New Roman, Helvetica, sans-serif;
}
body
{
text-align:center;
background-image:url("bg.jpg");
background-size:cover;
}

.topnav {
  overflow: hidden;
  background-color: white;
}
  
.topnav a {
  float: left;
  color: blue;
  text-align: center;
  padding: 8px 6px;
  text-decoration: none;
  font-size: 20px;
	
width:10%;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
h2 

  {
    color: tomato;
    text-align: center;
    
	margin-top:80px;
	margin-bottom:80px;

   }
h1{
	color:white;
}
h3{
	color:white;
}
.img{
	width:1800px;
	height:500px;
    }
.centered {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.text{
	width:105%;
	height:50%;
	
	margin-left:200px;
	margin-top:100px;
	 column-count: 2;
      }

</style>
</head>
<body>

<div class="topnav">
  <a href=admin.php>Back</a>


 
</div>







<html lang="en">
<head>
<style>
input[type=submit]{
    width: 100%;
	
	text-align: center;
  background-color: #4CAF50;
    padding: 10px 45px;
    margin: 2px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
th{
      width: 50px;
      height: 30px;
      background-color:white;
      color: black;

    }
    td{
      width: 50px;
      height: 30px;
	  color: white;
      

    }
    th,td{
      text-align: left;
      padding: 3px;
    }

</style>


    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
          window.scrollTo(0, 1);
		}



</script>
	
	
	
</head>

<body>

	<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="index.html"><span class="fa fa-gift"></span> SHOPPIE </a></h1>
			


<!-- banner -->
<div class="banner" id="home">

<div class="col-lg-6 col-md-6 px-lg-5 px-0">
					<div class="banner-form-w3 ml-lg-7">
						<h3 class="mb-3">Approve new shop</h3>
								


</div>
</div>
</div>

<div class="gtco-section border-bottom" >
		<div class="gtco-container" style="margin-top: -50px;">
			<div class="row">
				<div class="col-md-12">
					

				<div class="row form-group"  style="margin-top: 50px;padding-left: 40px;">
					<?php
$se=" select * from `login`,`registration_shop` WHERE login.logstatus=0 && login.loginid=registration_shop.loginid";
 $re=mysqli_query($con,$se);
?>
				<center>	<table border="1" style="width: 75%;">
						<tr style="height: 40px">
						    
						 
							
							<th style=" padding-left: 20px;">Name of Shop</th>
							<th style=" padding-left: 20px;">Contact No</th>
							
                            <th style=" padding-left: 20px;">Shop Registration Number</th>
							<th style=" padding-left: 20px;">Shopowner</th>
							<th style=" padding-left: 20px;">Street</th>
							<th style=" padding-left: 20px;">Locality</th>
							<th style=" padding-left: 20px;">District</th>
							<th style=" padding-left: 20px;">State</th>
							<th style=" padding-left: 20px;">Approve</th>
							<th style=" padding-left: 20px;">Reject</th>

							
						</tr>
						<?php
					
						
							while($row=mysqli_fetch_array($re))
  
 {
					?>
    <tr>
<td style="font-size: 15px;"> 
   <?php 
        echo $row['name'];
    ?>
  </td>
  <td style="font-size: 15px;"> 
   <?php 
        echo $row['contact_no'];
    ?>
  </td>
<td style="font-size: 15px;">

<?php
echo $row['shopreg_no'];
?>
</td>
<td style="font-size: 15px;">
<?php
echo $row['shop_owner'];
?>
</td>
<td style="font-size:15px;">
<?php
echo $row['street'];
?>
</td>
<td style="font-size: 15px;">
<?php
echo $row['locality'];
?>
</td>
<td style="font-size: 15px;">
<?php
echo $row['did'];
?>
</td>
<td style="font-size: 15px;">
<?php
echo $row['state'];
?>
</td>
<td>

  <form action="approve.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['loginid']; ?>"/>
    <input type="submit" value="Approve">
  </form>
</td>
<td>
  <form action="reject.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['loginid']; ?>"/>
    <input type="submit" value="Reject">
  </form>
  </td>
</tr>
<?php
}
?>
</table>
</center>
</body>
</html>



