<?php 
include 'co.php'; 
$q1="select * from brand";

 $db2=mysqli_query($co,$q1);
 
$q1l="select * from category";

 $db1=mysqli_query($co,$q1l);
?>





<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Shoppie</title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap-3.3.6-dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="navbar navbar-default navbar-fixed-top" id="topnav">
		<div class="container-fluid">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand">Shoppie</a>
			</div>


		</div>
	</div>
	<p><br><br></p>
	<p><br><br></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="err_msg"></div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Add Stock</div>
					<div class="panel-body">
				<form method="post" action="docreg.php" autocomplete="off">
					<div class="row">
						<div class="col-md-6">
							<label for="category">Product Category</label>
							<select name="category" id="category" name="category" class="form-control">
							<option name="category">Category</option>
							<?php 
							 while($fetch=mysqli_fetch_array($db1))  
							 {
							?>
                    <option value="<?php echo $fetch['cid']?>"><?php echo $fetch['ctitle']?> 
					<?php
							 }
                      ?>				
							</select>
						</div>
						<div class="col-md-6">
							<label for="brand">Brand</label>
							<select name="brand" id="brand" name="brand" class="form-control">
							<option name="brand">Brand</option>
							<?php
                                           while($fetch=mysqli_fetch_array($db2))
						                       {
                                         ?>
                                    <option value="<?php echo $fetch['bid']?>"><?php echo $fetch['btitle']?>  <?php
                                    }
						             ?>

							
							</select>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<label for="title">No Of Item</label>
							<input type="text" id="no_item" name="no_item" class="form-control">
						</div>
						<div class="col-md-6">
							<label for="price">Price</label>
							<input type="text" id="price" name="price" class="form-control">
						</div>
					</div>
                           <div class="col-md-6">
							<label for="name">Name</label>
							<input type="text" id="name" name="name" class="form-control">
						   </div>
                       

					<div class="row">
						<div class="col-md-6">
							<label for="mobile">Description</label>
							<input type="text" id="description" name="description" class="form-control">
						</div>
						
					</div>
                        <div class="row">
						<div class="col-md-6">
							<label for="mobile">Size</label>
							<select name="material" id="size" name="size" class="form-control">
							
                    <option>L</option>
                    <option>M</option>
                    <option>S</option>
                    </select>
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-6">
							<label for="address1">Image</label>
							<input type="file" id="image" name="image" class="form-control">
						</div>
						<div class="col-md-6"></div>
					</div>

					<div class="row">
						<div class="col-md-12">
							<label for="address2">Material</label>
							<select name="material" id="material" name="material" class="form-control">
<option>Shifon</option>
<option>Cotton</option>
<option>polyster</option>
<option>nylon</option>
<option>silk</option>
<option>Chunkidi</option>
<option>Jeans</option>
</select>
							
						</div>
					</div>

					<br><br>
					<div class="col-md-12">
						<input type="submit" class="btn btn-primary" value="Add" name="submit" id="submit">
					</div>

					</div>
					</div>
					</form>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>



<?php



if(isset($_POST['submit']))
 {
  $na=$_POST["category"];
$do=$_POST["brand"];
$gen=$_POST["no_item"];
$no=$_POST["price"];
$mn=$_POST["name"];
$em=$_POST["decsription"];
$pi=$_POST["size"];
$pa=$_POST["image"];
$hn=$_POST["material"]; 

$sql="insert into `products` ( `cid` , `bid` , `no_item` , `description` , `size` , `material` , `price` , `image`, `name`) values ('$na', '$do', '$gen', '$em', '$pi', '$hn', '$pa', '$mn' )";
$ch=mysqli_query($co,$sql);
if($ch)
{
	?>
	 <script>
 alert("Registration Successfull");
</script>
	<?php
}
else
{
  echo"error:".$sql."<br>".mysqli_error($co);
}
 }

mysqli_close($co);
?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js"></script>
	<script src="assets/bootstrap-3.3.6-dist/js/bootstrap.min.js"></script>
	<script src="main.js"></script>
</body>
<style> .foot{text-align: center;}
</style>
</html>