<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>The Shoppie</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>
	
	<!-- Header section -->
	<header class="header-section header-normal">
		<div class="container-fluid">
			<!-- logo -->
			<div class="site-logo">
				<img src="img/logon.png" alt="logo">
			</div>
			<!-- responsive -->
			<div class="nav-switch">
				<i class="fa fa-bars"></i>
			</div>
			<div class="header-right">
				<a href="cart.html" class="card-bag"><img src="img/icons/bag.png" alt=""><span>2</span></a>
				<a href="#" class="search"><img src="img/icons/search.png" alt=""></a>
			</div>
			<!-- site menu -->
			<ul class="main-menu">
				<li><a href="index.html">Home</a></li>
				<li><a href="#">Woman</a></li>
				<li><a href="#">Man</a></li>
				<li><a href="reg1.php">Back</a></li>
				<li><a href="minnu.php">Login</a></li>
				<li><a href="contact.html">Contact</a></li>
			</ul>
		</div>
	</header>
	<!-- Header section end -->


	<!-- Page Info -->
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="">Home</a> /
				<span>Add Stock</span>
			</div>
			<img src="img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	<!-- Page Info end -->


	<!-- Page -->
	
	<script language="javascript">
function abc()
{
if(document.form1.item1_name.value==""||document.form1.no1_item.value==""||document.form1.price1.value==""||document.form1.size1.value==""||document.form1.material1.value==""||document.form1.image1.value==""||document.form1.description1.value=="")
{
alert("enter the details");
return(false);
}
if((document.form1.item1_name.value)==true)
{
alert("Enter name");
return(false);
}

if(isNaN(document.form1.no1_item.value)==true)
{
alert("Phone should be numeric");
return(false);
}

if(isNaN(document.form1.price1.value)==true)
{
alert("Enter password");
return(false);
}
if((document.form1.size1.value)==true)
{
alert("enter shop registration number");
return(false);
}
if((document.form1.material1.value)==true)
{
alert("enter name of owner of shop");
return(false);
}

if((document.form1.image1.value)==true)
{
alert("Enter your street");
return(false);
} 
if((document.form1.description1.value)==true)
{
alert("Enter your locality");
return(false);
} 
}
</script>
</head>
	<body>
		   <div class="align-left">

		<h1 style="text-align:center; color:white;">Register Here</h1>
        
		<form action="itemimg.php" name="form1" id="form1" onSubmit="return abc()" method="POST">  
      
<table border="1" width="30%" align="center" cellspacing="10">
<tr><td>Item Name</td><td><input type="text" name="items_name" id="items_name"></td></tr>
<tr><td>No of Item</td><td><input type="text" name="no_items" id="no_items"></td></tr>
<tr><td>Price</td><td><input type="text" name="prices" id="prices"></td></tr>
<tr><td>Size of Item</td><td><select name="sizes" id="sizes">
<option>S</option>
<option>L</option>
<option>M</option>
</select></td></tr>
<tr><td>Material</td><td><select name="materials" id="materials">
<option>Shifon</option>
<option>Cotton</option>
<option>polyster</option>
<option>nylon</option>
<option>silk</option>
<option>Chunkidi</option>
<option>Jeans</option>
</select></td></tr>
<tr><td>Image</td><td><input type="file" name="images" id="images"></td></tr>
<tr><td>Description</td><td><input type="text" name="descriptions" id="descriptions"></td></tr>

<tr><td></td><td><input type="submit" name="submit" id="submit" value="submit"></td></tr>
</center></table>
            
</form>
</div>


      
<?php
include "connection.php";

if(isset($_POST['submit']))
{
$na=$_POST["items_name"];
$do=$_POST["no_items"];
$gen=$_POST["prices"];
$no=$_POST["sizes"];
$em=$_POST["materials"];
$pi=$_POST["images"];
$pa=$_POST["descriptions"];
$ndate=date("Y")."-".date("m")."-".date("d");

$sqll="insert into info_items(`items_name`,`no_items`,`prices`,`dates`,`sizes`,`materials`,`images`,`descriptions`) values ('$na','$do','$gen','$ndate','$no','$em','$pi','$pa')";
$obj=new db();
$obj->execute($sqll);

}
?>


	<section class="footer-top-section home-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-8 col-sm-12">
					<div class="footer-widget about-widget">
						<img src="img/logon.png" class="footer-logo" alt="">
						<p>The Shoppie...Gives You Trendy And Good Quality Clothes For You.Come And Shop..Let's 
Make The World Looks Beautiful.</p>
						<div class="cards">
							<img src="img/cards/5.png" alt="">
							<img src="img/cards/4.png" alt="">
							<img src="img/cards/3.png" alt="">
							<img src="img/cards/2.png" alt="">
							<img src="img/cards/1.png" alt="">
						</div>
					
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>