<?php
session_start();
include "connection.php";
$item_id=$_SESSION['item_id'];
$qty=$_SESSION['qty'];

  $obj=new db();
$selec="select * from products WHERE prodid='$item_id'";
$data1=$obj->execute($selec);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data1)>0)
{

while($row=mysqli_fetch_array($data1))
{
$itemname=$row['name'];	
$price=$row['price'];
$stock=$row['no_item'];

$total=$price*$qty;

}
}

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>The Shoppie</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>
	
	<!-- Header section -->
	<header class="header-section header-normal">
		<div class="container-fluid">
			<!-- logo -->
			<div class="site-logo">
				<img src="img/logon.png" alt="logo">
			</div>
			<!-- responsive -->
			<div class="nav-switch">
				<i class="fa fa-bars"></i>
			</div>
			<div class="header-right">
				<a href="cart.html" class="card-bag"><img src="img/icons/bag.png" alt=""><span>2</span></a>
				<a href="#" class="search"><img src="img/icons/search.png" alt=""></a>
			</div>
			<!-- site menu -->
			<ul class="main-menu">
				<li><a href="index.html">Home</a></li>
				
				<li><a href="checkout1.php">Back</a></li>
				<li><a href="contact.html">Contact</a></li>
				
			</ul>
		</div>
	</header>
	<!-- Header section end -->


	<!-- Page Info -->
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="">Home</a> /
				<span>Notification</span>
			</div>
			<img src="img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	
	<!-- Page Info end -->

	<!-- Page -->
	
	<script language="javascript">
function abc()
{
if(document.form1.comment1.value=="")
{
alert("enter the details");
return(false);
}

}

</script>


<body>
<form name="form1" onSubmit="return abc()" method='POST'>
<table width="200" border="1" align="center" cellspacing="10">
<tr>
<td colspan="2"><div align="center">Shipping Address</div></td>
</tr> 
<tr>
<td colspan="2"><textarea name="hname" cols="80"   placeholder="House Name" rows="1" id="hname" required/></textarea></td>
</tr>
<tr>
<td colspan="2"><textarea name="street" cols="80"   placeholder="Street" rows="1" id="street" required/></textarea></td>
</tr>
<tr>
<td colspan="2"><textarea name="locality" cols="80"   placeholder="Locality" rows="1" id="locality" required/></textarea></td>
</tr>
<tr>
<td colspan="2"><select name="district" required/>
<option>Tvm</option>
<option>Kollam</option>
<option>Pta</option>
<option>Alappuzha</option>
<option>Kottayam</option>
<option>Ekm</option>
<option>Idukki</option>
<option>Thrissur</option>
<option>Palakkad</option>
<option>Kozhikodu</option>
<option>Malappuram</option>
<option>Kannur</option>
<option>Wayanadu</option>
<option>Kazargodu</option>
</select></td>
<tr>
<td colspan="2"><div align="center">Add Card Details</div></td>
</tr>
<tr>
<td colspan="2"><input type="text" name="cardno" cols="80"   placeholder="Card Number" rows="1" id="cardno" pattern="[0-9]{16}" maxlength="16" required/></td>
</tr>
<tr>
<td colspan="2"><input type="number" name="expdate" cols="80"   placeholder="Expiry Date" rows="1" id="expdate" class="text_box" type="text" value="6" min="1" required/>
<input type="number" class="text_box" type="text" value="2019" min="1" />
</td>
</tr>
<tr>
<td colspan="2"><input type="text" name="cvv" cols="80"   placeholder="Cvv" rows="1" id="cvv" pattern="[0-9]{3}" maxlength="3" required/></td>
</tr>
<tr>
<td colspan="2"><div align="center">
<input type="submit" name="submit" value="submit">
      
</div></td>
</tr> 
</table>
</form>

<?php
$bcid=$_SESSION['lid'];
if(isset($_POST['submit']))
{
$i=rand();
$cm=$_POST["hname"];
$ab=$_POST["street"];
$cd=$_POST["locality"];
$ef=$_POST["district"];
$total=$_POST["total"];
$ndate=date("Y")."-".date("m")."-".date("d");
$total=$price*$qty;
$sql="insert into payment(`prodid`,`loginid`,`amt`,`hname`,`locality`,`street`,`district`,`paydate`,`trid`,`qty`) values('$item_id','$bcid','$total','$cm','$cd','$ab','$ef','$ndate','$i','$qty')";
$obj=new db();
$obj->execute($sql);
 echo "<script> 
 window.location='payment2.php'</script>";
}

?>
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>
