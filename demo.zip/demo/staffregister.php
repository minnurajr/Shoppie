
<?php

include 'conn.php';
$q="select * from districts";
  $sq=mysqli_query($con,$q); 								
?>


<!DOCTYPE html>
<html>
<head>
<script>
function validateForm() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Registeration completed");
        return false;
    }
}
</script>
<style>
body
{
<body background="regcustomer.jpg">
}

input[type=text],[type=date],[type=button],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}
.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: right;
  color: #f2f2f2;
  text-align: center;
  padding: 8px 6px;
  text-decoration: none;
  font-size: 20px;
	
width:10%;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
body {
  margin: 5;
  padding: 100;
  background:grey;
  font-size: 16px;
  color: #222;
  font-family: 'Roboto', sans-serif;
  font-weight: 300;
}
h2 

  {
    color: tomato;
    text-align: center;
    
	margin-top:80px;
	margin-bottom:80px;

   }
h1{
	color:white;
}

.img{
	width:180px;
	height:50px;
    }
.centered {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.text{
	width:105%;
	height:50%;
	margin-left:200px;
	margin-top:100px;
	 column-count: 2;
      }
.footer {
  position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height:8%;
   background-color: black;
   margin-top:100px;
}
ul{
margin:0px;
padding:0px;
list-style:none;
}
ul li{
float:left;
width:200px;
height:60px;
background-color:yellow;
opacity:.5;
line-height:50px;
text-align:center;
font-size:20px;
margin-right:30px;
}
ul li a{
text-decoration:none;
}
ul li a:hover{
background-color-green;

}
ul li ul li
{
display:none;l
}
ul li:hover ul li{
display:block;
}


h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:black;
}

input[type=submit],[type=button] {
    
    background-color:green;
    padding: 12px 25px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
.container {
    border-radius:55px;
    background-image: url("regcustomer.jpg");
    padding: 10px;
    margin-left:700px;
width:40%;
 
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

</style>
</head>
<body >

<div class="container">
<h1>Registration Form</h1>
 <form name="myForm" method="post" action="staffregister.php" autocomplete="off"


   onsubmit="return validateForm()" method="post">

    <div class="row">
      <div class="col-25">
        <label for="name">Name</label>
      </div>
      <div class="col-75">
   <input type="text" name="name" pattern="[A-Z/a-z]{1,20}" required title="Enter only characters">
       
      </div>
    </div>
    
    <div class="row">
      <div class="col-25">
        <label for="address">Address</label>
      </div>
      <div class="col-75">
        <textarea  name="address" placeholder="Address.."required style="height:100px"></textarea>
      </div>
    </div>

 
      
<div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="email"  name="email" placeholder="Email id.." required>
      </div>
    </div>
<div class="row">
      <div class="col-25">
        <label for="dob">Password</label>
      </div>
      <div class="col-75">
 <input type="password" id="password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
       
      </div>
<div class="row">
      <div class="col-25">
        <label for="did">districts:</label>
      </div>
<select  name="did" id="did" class="form-control">
		                      	<option value="district">Select district</option>
		                        <?php 
								while($r=mysqli_fetch_array($sq))
   								{
									?>
   								
<option value="<?php echo $r['did'];

//echo "<script> alert($cid);
           //window.location='company.php'</script>";


?>"><?php echo $r['districtname']?>


<?php
}
?>

		                    </select><br>
	 
 
 
    <input type="submit" name="submit" value="submit">





  
</div>

 </form>


<?php
 include "connection.php";
 if(isset($_POST['submit']))
{

$fn=$_POST['name'];

$ad=$_POST['address'];

$email=$_POST['email'];
$pas=md5($_POST['password']);
$d=$_POST['did'];

$sql="INSERT INTO `login`(`loginid`, `username`, `password`, `usertype`, `role`, `logstatus`) values( NULL,'$email','$pas',1,'staff',0)";
$obj=new db();
$obj->execute($sql);
$sel="select loginid from login where username='$email' and password='$pas'";
$login=$obj->execute($sel);
//echo $login; error due to string
$strr=mysqli_fetch_array($login);
 //echo $strr[0];
//echo "success";
$lo=$strr[0];






$sqlll="INSERT INTO `userregister`(`regid`, `name`, `address`, `did`, `loginid`) VALUES(NULL,'$fn','$ad' ,'$d', '$lo')";
$objj=new db();
$objj->execute($sqlll);
 //echo "<script> alert('Successfully registered');
          // window.location='login.php'</script>";

}
 
  
  //echo "<script> ('Success');
          // window.location='Org1.php'</script>";

// header("location:ORG1.php");

?>


</body>
</html>