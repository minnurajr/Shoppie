

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Shoppie</title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap-3.3.6-dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="navbar navbar-default navbar-fixed-top" id="topnav">
		<div class="container-fluid">
			<div class="navbar-header">
			
				<a href="index.html" class="navbar-brand">Shoppie</a>
				<a href="reg1.php">Registration</a>
				
				<a href="contact.html">Contact</a>
				<a href="about.php">About Us</a>
			</div>


		</div>
	</div>
	<p><br><br></p>
	<p><br><br></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="err_msg"></div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Login</div>
					<div class="panel-body">
				<form method="post" action="newlog.php" autocomplete="off">
					

					<div class="row">
						<div class="col-md-6">
							<label for="title">Username</label>
							<input type="text" id="username" name="username" class="form-control" required/>
						</div>
						<div class="col-md-6">
							<label for="price">Password</label>
							<input type="password" id="password" name="password" class="form-control" required/>
						</div>
					</div>
                           <div class="row">
						<div class="col-md-6">
							Not Have An Accout!!
							<a href="reg1.php">sign up</a>
						</div>
						<div class="col-md-6"></div>
					</div>

					<br><br>
					<div class="col-md-12">
						<input type="submit" class="btn btn-primary" value="Login" name="submit" id="submit">
					</div>

					</div>
					</div>
					</form>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>







		<?php 

include("connection.php");
session_start();
 if(isset($_POST['submit']))
 {
	$em=$_POST['username'];
	echo $em;
	$pa=$_POST['password'];
	echo $pa;
	$obj=new db();
	$select="select * from login where username='$em' and password='$pa' and logstatus='1'";
	echo $select;
	$data=$obj->execute($select);
	if(mysqli_num_rows($data)>0)
	{
		while($row=mysqli_fetch_array($data))
		{
		
			if($row['role']=='admin')
			{
				$_SESSION['lid']=$row['loginid'];
				$_SESSION['role']=$row['role'];
				header("location:admin.php");
			}
			if($row['role']=='customer')
			{
				$_SESSION['lid']=$row['loginid'];
				$_SESSION['role']=$row['role'];
				header("location:userhome.php");
			}
                        if($row['role']=='shop')
			{
				$_SESSION['lid']=$row['loginid'];
				$_SESSION['role']=$row['role'];
				header("location:shop.php");
			}
                        
		}
	}
	else
	{
		?>
		<script>
		alert("check username and password");
		window.location="newlog.php";
		</script>
		<?php
		
		
	}
 }
?>




		


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js"></script>
	<script src="assets/bootstrap-3.3.6-dist/js/bootstrap.min.js"></script>
	<script src="main.js"></script>
</body>
<style> .foot{text-align: center;}
</style>
</html>