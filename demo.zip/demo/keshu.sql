-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2019 at 10:51 AM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `keshu`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `bid` int(11) NOT NULL,
  `btitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`bid`, `btitle`) VALUES
(1, 'LP'),
(2, 'Roshni'),
(3, 'OTTO'),
(4, 'Vismaya'),
(5, 'Rixo'),
(6, 'Ramraj'),
(7, 'Nstyle');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `prodid` int(50) NOT NULL,
  `loginid` int(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cid` int(11) NOT NULL,
  `ctitle` varchar(200) NOT NULL,
  `tid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cid`, `ctitle`, `tid`) VALUES
(1, 'shirt', 1),
(2, 'saree', 2),
(3, 'mundu', 1),
(4, 'nighty', 2),
(5, 'jeans', 1),
(6, 'top', 2),
(7, 'churidar', 2),
(8, 'kaily', 1),
(9, 'shall', 2);

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `did` int(11) NOT NULL,
  `districtname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`did`, `districtname`) VALUES
(1, 'thiruvananthapuram'),
(2, 'kollam'),
(3, 'pathanamthitta'),
(4, 'alappuzha'),
(5, 'kottayam'),
(6, 'idukki'),
(7, 'eranakulam'),
(8, 'thrissur'),
(9, 'palakkadu'),
(10, 'kozhikodu'),
(11, 'wayanadu'),
(12, 'malappuram'),
(13, 'kannur'),
(14, 'kasargodu');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `imageid` int(100) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`imageid`, `image`) VALUES
(1, 'mjns4.jpg'),
(2, 'images (11).jpg'),
(3, '1-s2.0-S0020025510000034-main.pdf'),
(4, '1-s2.0-S1361372318301076-main.pdf'),
(5, 'download (14).jpg'),
(6, ''),
(7, 'admin_v01D_support.png'),
(8, '1-s2.0-S0020025510000034-main.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `loginid` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `logstatus` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`loginid`, `username`, `password`, `usertype`, `role`, `logstatus`) VALUES
(1, 'adminadmin', 'admin@12', '0', 'admin', 1),
(27, 'ch@gmail.com', 'hhh', '2', 'shop', 0),
(32, 'niya1@gmail.com', 'Niyaroy@12', '1', 'customer', 0),
(29, 'manu1@gmail.com', 'mma', '2', 'shop', 0),
(28, 'alb@gmail.com', 'cf42b1c2b8978b5f4b9cd051dfedf7cd', '2', 'shop', 0),
(31, 'anju@gmail.com', 'Anju@12345', '2', 'shop', 0),
(30, 'amrutha@gmail.com', 'Amrutha@123', '1', 'customer', 0),
(21, 'oo', 'ggg', '1', 'customer', 0),
(36, 'meera@gmal.com', 'jjjknkj', '2', 'shop', 0),
(26, 'pooja@gmail.com', 'poojas', '2', 'shop', 0),
(37, 'deepa12@gmail.com', 'Deepa@1234', '2', 'shop', 0),
(41, 'jj12@gmail.com', 'kkkkkk@123', '2', 'shop', 0),
(40, 'hjkh@gmail.com', 'mmm@hhhhhh', '2', 'shop', 0),
(42, 'shru@gmail.com', 'shruthi@123', '1', 'customer', 1),
(43, 'anju@gmail.com', 'Anjuu@12345', '2', 'shop', 1),
(48, 'aaa@gmail.com', 'appu@1234', '1', 'customer', 1),
(47, 'kk@gmail.com', 'kkkk@12345', '2', 'shop', 1),
(49, 'ggg@gmail.com', 'oooo89562@', '1', 'customer', 1),
(53, 'mahesh12@gmail.com', 'mahesh@123', '1', 'customer', 1),
(51, 'raj123@gmail.com', 'raj@12345', '2', 'shop', 1),
(61, 'minnu@gmail.com', 'minnuchinju', '2', 'shop', 1),
(54, 'hb', 'bhb', '1', 'customer', 1),
(60, 'sh@gmail.com', 'shsh@12', '2', 'shop', 1),
(59, 'zoya@gmail.com', 'zoya@123', '1', 'customer', 1),
(57, 'jhjh', 'hj', '1', 'customer', 1),
(58, 'sree@gmail.com', 'sree@12345', '2', 'shop', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notification_no` int(50) NOT NULL,
  `notifications` varchar(100) NOT NULL,
  `notif_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notification_no`, `notifications`, `notif_date`) VALUES
(5, 'exclusive offers today at 1 PM', '2019-10-03'),
(4, 'offers here', '2019-10-03'),
(6, 'Mega offer @ 5 PM', '2019-10-03'),
(7, 'offerssss', '2019-10-03'),
(8, 'check ll notifications', '2019-10-03'),
(9, 'offer@2 PM', '2019-10-16'),
(10, '', '2019-10-28');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pay_no` int(100) NOT NULL,
  `prodid` int(11) NOT NULL,
  `loginid` int(11) NOT NULL,
  `amt` varchar(500) NOT NULL,
  `paydate` date NOT NULL,
  `hname` varchar(500) NOT NULL,
  `street` varchar(200) NOT NULL,
  `locality` varchar(500) NOT NULL,
  `district` int(11) NOT NULL,
  `trid` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pay_no`, `prodid`, `loginid`, `amt`, `paydate`, `hname`, `street`, `locality`, `district`, `trid`) VALUES
(1, 0, 0, '', '2019-11-08', '', '', '', 0, 1665141987);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prodid` int(50) NOT NULL,
  `cid` varchar(100) NOT NULL,
  `bid` varchar(100) NOT NULL,
  `no_item` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `size` varchar(100) NOT NULL,
  `material` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `image` varchar(500) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prodid`, `cid`, `bid`, `no_item`, `description`, `size`, `material`, `price`, `image`, `name`) VALUES
(1, '5', '1', '1', 'Black Jeans', 'M', 'Jeans', '1229', 'mjns3.jpg', 'Jeans'),
(2, '3', '5', '1', 'white with red kasavu', 'L', 'Cotton', '499', 'mnd1.jpg', 'Red kasav mundu'),
(3, '5', '1', '1', 'new style blue color', 'L', 'Jeans', '999', 'mjns4.jpg', 'blue jeans'),
(4, '2', '2', '1', 'velvet saree with red color', 'L', 'Shifon', '1599', 'images (28).jpg', 'Red velvet '),
(5, '6', '4', '1', 'Black top with  sleevless', 'M', 'Shifon', '988', 'images (15).jpg', 'Black lady'),
(6, '4', '7', '1', 'Red color nighty', 'M', 'Cotton', '478', 'download (14).jpg', 'Style me'),
(7, '7', '2', '1', 'Umbrella cut churidar with red color', 'M', 'Cotton', '1999', 'download (5).jpg', 'Cuty'),
(8, '1', '3', '1', 'good', 'M', 'Cotton', '899', 'mnd2.jpg', 'shirt'),
(9, '6', '4', '1', 'Black top with Works', 'M', 'Shifon', '599', 'download (10).jpg', 'Beauty');

-- --------------------------------------------------------

--
-- Table structure for table `registration_shop`
--

CREATE TABLE `registration_shop` (
  `shop_id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `shopreg_no` varchar(50) NOT NULL,
  `shop_owner` varchar(50) NOT NULL,
  `street` varchar(50) NOT NULL,
  `locality` varchar(50) NOT NULL,
  `did` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `loginid` int(100) NOT NULL,
  `username` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration_shop`
--

INSERT INTO `registration_shop` (`shop_id`, `name`, `contact_no`, `shopreg_no`, `shop_owner`, `street`, `locality`, `did`, `state`, `loginid`, `username`) VALUES
(1, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 0, ''),
(2, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 0, ''),
(3, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 0, ''),
(7, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 0, ''),
(8, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 0, ''),
(12, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 0, ''),
(11, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 0, ''),
(13, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 43, ''),
(19, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 51, ''),
(17, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 47, ''),
(21, 'shana', '', '', '', 'kjk', 'kjnk', 'district', 'Kerala', 58, ''),
(22, 'shana', '2255447788', '65165', 'manu', 'advi', 'ranni', 'district', 'Kerala', 60, 'sh@gmail.com'),
(23, 'minnu', '8977447785', '65434', 'rajendran', 'konni', 'konni', '3', 'Kerala', 61, 'minnu@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `registration_user`
--

CREATE TABLE `registration_user` (
  `userid` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `mobno` varchar(50) NOT NULL,
  `pincode` varchar(50) NOT NULL,
  `hname` varchar(50) NOT NULL,
  `street` varchar(50) NOT NULL,
  `locality` varchar(50) NOT NULL,
  `did` int(11) NOT NULL,
  `state` varchar(50) NOT NULL,
  `loginid` int(20) NOT NULL,
  `username` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration_user`
--

INSERT INTO `registration_user` (`userid`, `name`, `dob`, `gender`, `mobno`, `pincode`, `hname`, `street`, `locality`, `did`, `state`, `loginid`, `username`) VALUES
(1, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 0, ''),
(2, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 0, ''),
(3, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 0, ''),
(4, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 0, ''),
(5, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 0, ''),
(6, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 0, ''),
(20, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 32, ''),
(19, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 30, ''),
(14, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 0, ''),
(15, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 22, ''),
(21, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 42, ''),
(22, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 48, ''),
(23, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 49, ''),
(24, 'zoya', '8/9/77', 'm', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 57, ''),
(25, 'zoya', '8/9/77', 'f', '8956231477', '5465', 'chaithanya', 'koodal', 'cherthala', 0, 'Kerala', 59, 'zoya@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `item_id` int(200) NOT NULL,
  `no_item` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `tid` int(11) NOT NULL,
  `tname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`tid`, `tname`) VALUES
(1, 'men'),
(2, 'women');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`imageid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`loginid`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification_no`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_no`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prodid`);

--
-- Indexes for table `registration_shop`
--
ALTER TABLE `registration_shop`
  ADD PRIMARY KEY (`shop_id`),
  ADD KEY `loginid` (`loginid`);

--
-- Indexes for table `registration_user`
--
ALTER TABLE `registration_user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`tid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `imageid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `loginid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notification_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prodid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `registration_shop`
--
ALTER TABLE `registration_shop`
  MODIFY `shop_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `registration_user`
--
ALTER TABLE `registration_user`
  MODIFY `userid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
