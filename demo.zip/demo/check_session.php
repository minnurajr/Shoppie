<?php 
session_start();
if(isset($_SESSION['lid'])&& $_SESSION['lid']!="")
{}
else
{
   header("location:newlog.php");
}

$inactive=1000;
if(isset($_SESSION['timeout']))
{
	$sessionttl=time()- $_SESSION['timeout'];
	if($sessionttl > $inactive)
	{
	session_destroy();
	header("location:newlog.php");	
	}	
}
$_SESSION['timeout']=time();
?>