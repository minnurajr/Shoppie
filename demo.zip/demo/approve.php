<?php
include "conn.php";

$b=$_POST['id'];
 

$sqll=mysqli_query($con,"update login set logstatus=1 where loginid='$b'");
if (  $sqll ){
echo "<script>alert('Approved');
      window.location='approval1.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>