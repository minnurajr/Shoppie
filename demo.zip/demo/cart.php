<?php
	session_start();
	
	$Lid=$_SESSION['lid'];
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Shoppie</title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap-3.3.6-dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="navbar navbar-default navbar-fixed-top" id="topnav">
		<div class="container-fluid">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand">Shoppie</a>
			</div>


		</div>
	</div>
	<p><br><br></p>
	<p><br><br></p>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
			<div class="row">
				<div class="col-md-12" id="cart_msg"></div>
			</div>
				<div class="panel panel-primary text-center">
					<div class="panel-heading">Cart Checkout</div>
					<div class="panel-body"></div>
					<!----
					<div class="row">
						<div class="col-md-2"><b>Action</b></div>
						<div class="col-md-2"><b>Product Image</b></div>
						<div class="col-md-2"><b>Product Name</b></div>
						<div class="col-md-2"><b>Product Price</b></div>
						<div class="col-md-2"><b>Quantity</b></div>
						<div class="col-md-2"><b>Price</b></div>
					</div>
					------>
					<br><br>
					<div id='cartdetail'>
					<?Php
					include("connection.php");
$Lid=$_SESSION['lid'];
if($Lid>0)
{
$obj=new db();
	$select="select * from cart,products where cart.prodid = products.prodid && cart.loginid = '$Lid'";
	$data=$obj->execute($select);
	$row=mysqli_fetch_array($data);
	?>
	
	
	
	
	
	
	<center>	<table border="1" style="width: 75%;">
						<tr style="height: 40px">
						    
						 
							
							<th style=" padding-left: 20px;">Name </th>
							<th style=" padding-left: 20px;">Price</th>
							
                            <th style=" padding-left: 20px;">Image</th>
							<th style=" padding-left: 20px;">Quantity</th>
							

							
						</tr>
	
	
	
	
	  <tr>
<td style="font-size: 15px;"> 
  
        <?php echo $row['name'];?>
   
  </td>
  <td style="font-size: 15px;"> 
   <?php 
        echo $row['price'];
    ?>
  </td>
<td style="font-size: 15px;">


<img src="upload/<?php echo $row['image']; ?>"  style="width:30%" height="40%">

</td>
	<td style="font-size: 15px;">


<input type="number" name="quantity" pattern="[0-9]" required/>

</td>
	</tr>
	
	</table>
</center>
<?php 
}	
?>
		
	
	
	<!----
	<center>
	 <table border="1" style="width: 50%;">
						
	<tr>
	<th><label>Name</label></th>
	<td><?php echo $row['name'];?></td>
	</tr>
	
	<tr>
	<th><label>Price</label></th>
	<td><?php echo $row['price'];?></td>
	</tr>
	<tr>
	<th><label>Image</label></th>
	<td> <img src="upload/<?php echo $row['image']; ?>"  style="width:30%" height="40%"></td>
	</tr>
	</table>
	</center>
------>
	
<?php $prodid=$row['prodid'];
?>

					</div>
					
					<div class="panel-footer">

					</div>
				</div>
				<button class='btn btn-success btn-lg pull-right' id='checkout_btn' data-toggle="modal" data-target="#myModal"><a href=jn.php?id=<?php echo $prodid;?>">Checkout</a></button>
			</div>

			<div class="col-md-2"></div>
		</div>
	</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js"></script>
	<script src="assets/bootstrap-3.3.6-dist/js/bootstrap.min.js"></script>
	<script src="main.js"></script>
</body>

<style> .foot{text-align: center;}
</style>
</html>
